function setup() {
  createCanvas(500, 500);
  background(50);
  stroke(255);
  fill(255);
  
  for(var i = 0 ; i < 100 ; i+=.1)
    {
  let r = random(0,500);
  let s = random(0,500);
      point(r,s);
    }

}
