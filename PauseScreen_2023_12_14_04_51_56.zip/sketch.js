var highlightPosition = 0;
var wasPausePressed = false;
var inPauseScreen = 0;

function setup() {
  createCanvas(1000, 1000);
}

function draw() {
  background(255);
  strokeWeight(1);
  fill(0,255,0);
  rect(500,100,150,150);
  if(inPauseScreen == 1){
  //creates the interactive pause screen
  inPauseScreen = 1;
  wasPausePressed = true;
  strokeWeight(0);
  stroke(0,0,0);
  fill(50,50,50,195);
  rect(0,0,1000,1000);
  stroke(0,0,0);
  fill(255,255,255);
  textSize(50);
  if(highlightPosition == 0)
    {
      strokeWeight(10);
    }
  else
  {
    strokeWeight(0);
  }
  text('Resume',410,475);
  if(highlightPosition == 1)
    {
      strokeWeight(10);
    }
  else
  {
    strokeWeight(0);
  }
  text('Quit',455,575);
  }
}

function keyPressed() {
  if((key == 'p') && (wasPausePressed == false)) {
  inPauseScreen = 1;
  }
  if((inPauseScreen == 1) && (key == 'w')) {
    highlightPosition = 0;
  }
  else if((inPauseScreen == 1) && (key == 's')) {
    highlightPosition = 1;
  }
  if((inPauseScreen == 1) && (highlightPosition == 0) && (keyCode === ENTER))
    {
      inPauseScreen = 0;
      wasPausePressed = false;
    }
  else if((inPauseScreen == 1) && (highlightPosition == 1) && (keyCode === ENTER)) {
    remove();
  }
}