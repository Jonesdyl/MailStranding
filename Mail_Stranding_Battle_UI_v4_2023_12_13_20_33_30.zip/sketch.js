new p5();
var inBattle = 0;
//state 1 is selecting move, state 2 is selecting enemy, state 3(?) is player damage phase
//state 0 is overworld movement, state 4 is enemy damage phase, state 5 is battle won, state 6 is level up(?)
var battleState = 1;
var trianglePos = 1;
var power = 10;
var secretKey = 0;
var ultraSecret = 0;
var maxPlayerHealth= 50;
var playerHealth = 50;
var easyEnemyHealth = 30;
var easyEnemyPower = 3;
var hardEnemyHealth = 70;
var hardEnemyPower = 7;
var damageDealt;
var enemiesKilled=0;
var topEnemyX=850;
var topEnemyY=250;
var bottomEnemyX=750;
var bottomEnemyY=400;
//following 2 probably aren't going to get used
var trianglePoints = [75,750,125,780,75,810];
var triangleTranslate1x=0;
//0 is idle, 1/2/3/4 are player moves
var moveSelect = 1;
var playerTimer=new Timer(3000);
var enemyTimer=new Timer(3000);
var secretKillTimer=new Timer(3000);
var enemyTurn=0;
var hasMoved=false;

let img;

let movingRight = false;
let movingLeft = false;
let movingUp = false;
let movingDown = false;

let xpos = 300;
let ypos = 300;
let speed = 5;


function preload(){
  img=loadImage("starbackground.png");
}

function damageCalculate(x,y){
  var damage;
  if (moveSelect==1){
  damage = round(random(x*0.7,x*1.3));
  }
  if (moveSelect==2){
  damage = round(random(x,x*1.7));  
  }
  if (moveSelect==3){
  damage = x*0.8;  
  }
  var crit=random(1,10);
  if (crit<=y) {
    damage*=2;
  }
  return(damage);
}
//draw erase triangles according to movement
function eraseTriangle(){

  push();
  stroke(300);
  strokeWeight(10);
  triangle(75,750,125,780,75,810);
  triangle(525,750,575,780,525,810);
  triangle(525,850,575,880,525,910);
  triangle(75,850,125,880,75,910);
  pop();
}

//draws background, menu, and text as well as initial triangle
function setup() {
  frameRate(1000);
  createCanvas(1000, 1000);
  background(220);
  rect(50,700,900,250);
  textSize(50);
  text('Punch',150,800);
  text('Gun',600,800);
  text('Flamethrower',150,900);
  text('Heal',600,900);
  triangle(75,750,125,780,75,810);
  playerTimer.pause();
  enemyTimer.pause();
  secretKillTimer.pause();
  print('^^^PLEASE IGNORE THE ABOVE WARNING, THE TIMER DOESN\'T WORK WITHOUT A SECOND IMPORT^^^');
}
//draws character,enemies, and health numbers, as well as descriptions(WIP) and battle end screen
function draw() {
  if (inBattle==0){
    
    image(img,0,0);
    
    // draw moving character
  fill(0, 0, 255);
  ellipse(xpos, ypos, 75, 75);
  
  // update moving character
  if (movingRight) {
    xpos += speed;
  }
  if (movingLeft) {
    xpos -= speed;
  }
  if (movingUp) {
    ypos -= speed;
  }
  if (movingDown) {
    ypos += speed;
  }
  }
  if (inBattle==1){
  var playerTimerLeft=playerTimer.getRemainingTime();
  var enemyTimerLeft=enemyTimer.getRemainingTime();
  var secretKillTimerLeft=secretKillTimer.getRemainingTime();
    if (battleState!=5){
  push();
  fill(0,250,150);
  ellipse(150,300,75,150);
  pop();
  rect(10,275,90,50);
  text(playerHealth,20,320);
  push();
  fill(250,200,0);
  ellipse(850,250,75,150);
  pop();
  rect(900,225,90,50);
  text(easyEnemyHealth,910,270);
  push();
  fill(255,0,0);
  ellipse(750,400,75,150);
  pop();
  rect(800,375,90,50);
  text(hardEnemyHealth,810,420);
  if (trianglePos==1){
    describe('Lunge forward and punch the enemy! Deals 70-130% Damage, 30% crit rate',LABEL);
  }
  if (trianglePos==2){
    describe('Fire your trusty gun at the enemy! Deals 100-170% damage, 10% crit rate',LABEL);
  }
  if (trianglePos==3){
    describe('Pull out your flamethrower and burn the enemy! Deals 80% damage, 60% crit rate',LABEL);
  }
  if (trianglePos==4){
    describe('Grab some bandages and restore your health! Recovers 20% of your max HP',LABEL);
  }
  if (trianglePos==5){
    describe('Easy Enemy, '+easyEnemyHealth+ ' HP',LABEL);
  }
    if (trianglePos==6){
    describe('Hard Enemy, '+hardEnemyHealth+ ' HP',LABEL);
  }
  
  if (playerTimerLeft<1500&&hasMoved==false){
    if (trianglePos==5&&moveSelect!=4){
      text(damageDealt,650,250);
      easyEnemyHealth-=damageDealt;
    }
    
    if (trianglePos==6&&moveSelect!=4){
      hardEnemyHealth-=damageDealt;
      text(damageDealt,550,400);
    }
    if (moveSelect==4){
      text(damageDealt,100,200)
      playerHealth+=damageDealt;
    }
    if (easyEnemyHealth<0){
      easyEnemyHealth=0;
      enemiesKilled++;
    }
    if (hardEnemyHealth<0){
      hardEnemyHealth=0;
      enemiesKilled++;
    }
    if (playerHealth>50){
      playerHealth=50;
    } 
    hasMoved=true;
  }
  
  if (playerTimerLeft==0){
    playerTimer.reset();
    playerTimer.pause();
    print("player turn over");
    hasMoved=false;
    enemyTimer.start();
    enemyTurn=1;
    moveSelect=1;
  }
    
  if (enemyTimerLeft<1500&&hasMoved==false){
      push();
      noStroke();
      fill(220);
      rect(315,235,100,100);
      pop();
      if (enemyTurn==1){
      damageDealt=damageCalculate(easyEnemyPower,3);
      }
      else if (enemyTurn==2){
      damageDealt=damageCalculate(hardEnemyPower,3);
      }
      text(damageDealt,350,300);
      playerHealth-=damageDealt;
      print(playerHealth);  
      hasMoved=true;
  }  
    
  if (enemyTimerLeft==0){
    if (enemyTurn==1){
    enemyTimer.reset();
    print("enemy 1 turn over");
    if (enemiesKilled==1){
      enemyTimer.pause();
      hasMoved=false;
      trianglePos=1;
      triangle(75,750,125,780,75,810);
      battleState=1;
      enemyTurn=0;
    }
      else{
        enemyTurn=2;
        hasMoved=false;
      }
    }
    else if (enemyTurn==2){
    enemyTimer.reset();
    enemyTimer.pause();
      hasMoved=false;
    print("enemy 2 turn over");
    trianglePos=1;
    triangle(75,750,125,780,75,810);
    battleState=1;
    enemyTurn=0;
    }
  }
  
  if (easyEnemyHealth<=0){
    easyEnemyHealth=0;
    push();
    fill(220);
    stroke(220);
    strokeWeight(5);
    ellipse(850,250,75,150);
    rect(900,225,90,50);
    pop();
  }
  if (hardEnemyHealth<=0){
    hardEnemyHealth=0;
    push();
    fill(220);
    stroke(220);
    strokeWeight(5);
    ellipse(750,400,75,150);
    rect(800,375,90,50);
    pop();
  }
    if (enemiesKilled==2){
      secretKillTimer.start();
      if (secretKillTimerLeft==0){
        battleState=5;
        rect(0,0,1000);
        text('Battle Won!',400,500);
  }
    }
  
  }
  }
}

//trianglePos/moveSelect 1/2/3/4 coresponds to A/B/C/D, tiranglePos 5/6 corresponds to top/bottom enemy

function keyPressed() {
  if(inBattle==0){
     if (key == 'w') {
    movingUp = true;
  }
  if (key == 'a') {
    movingLeft = true;
  }
  if (key == 's') {
    movingDown = true;
  }
  if (key == 'd') {
    movingRight = true;
  }
  }
  if (inBattle==1 && battleState==1){

    if (keyCode === LEFT_ARROW) {
      if (secretKey==2) {
      secretKey=3;
      print(secretKey);
      }
      if (trianglePos == 2) {
        //move to A
        eraseTriangle();
        triangle(75,750,125,780,75,810);
        trianglePos=1;
          }
      if (trianglePos == 4) {
        //move to C
        eraseTriangle();
        triangle(75,850,125,880,75,910);
        trianglePos=3;
      }
    } 
    else if (keyCode === RIGHT_ARROW) {
      if (secretKey==3) {
      secretKey=4;
      print(secretKey);
      }
        if (trianglePos == 1)
          {
            //move to B
            eraseTriangle();
            triangle(525,750,575,780,525,810);
            trianglePos=2;
          }
      if (trianglePos == 3)
          {
            //move to D
            eraseTriangle();
            triangle(525,850,575,880,525,910);
            trianglePos=4;
      }
    }
    else if (keyCode === UP_ARROW) {
      secretKey=1;
      print(secretKey);
      if (trianglePos == 3) {
        //move to A
        eraseTriangle();
        triangle(75,750,125,780,75,810);
        trianglePos=1;
          }
      if (trianglePos == 4) {
        //move to B
        eraseTriangle();
        triangle(525,750,575,780,525,810);
        trianglePos=2;
      }
    }
    else if (keyCode === DOWN_ARROW) {
      if (secretKey==1) {
      secretKey=2;
      print(secretKey);
      }
      if (trianglePos == 1) {
        //move to C
        eraseTriangle();
        triangle(75,850,125,880,75,910);
        trianglePos=3;
          }
      if (trianglePos == 2) {
        //move to D
        eraseTriangle();
        triangle(525,850,575,880,525,910);
        trianglePos=4;
      }
    }
    
    else if (keyCode === 32){
    if (secretKey==4){
      ultraSecret++;
      secretKey=0;
      }
      if (ultraSecret>=5){
        secretKillTimer.start();
        push();
        noStroke();
        fill(255,0,0);
        rect(0,0,1000,600);
        pop();
        text('ANNIHILATE!!!',300,100);
        easyEnemyHealth=0;
        hardEnemyHealth=0;
        enemiesKilled=2;
      }
      if (trianglePos == 1||2||3||4){
        moveSelect=trianglePos;
        if(easyEnemyHealth==0){
        trianglePos=6;
        }
        else {
          trianglePos=5;
        }
        battleState=2;
      }
    }
        else {
    secretKey=0;
    }
  }
  if (inBattle==1 && battleState==2){
    //erase all triangles from move select
     push();
      stroke(300);
      strokeWeight(10);
      triangle(75,750,125,780,75,810);
      triangle(525,750,575,780,525,810);
      triangle(75,850,125,880,75,910);
      triangle(525,850,575,880,525,910);
      pop();
    //create triangles for enemies
    if (easyEnemyHealth>0){
      push();
    stroke(0);
    strokeWeight(1);
    fill(255);
    triangle(700,220,750,250,700,280);
      pop();
      push();
      stroke(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      pop();
    }
    else {
      push();
    stroke(0);
    strokeWeight(1);
    fill(255);
    triangle(600,370,650,400,600,430);  
      pop();
      push();
      stroke(220);
      strokeWeight(10);
      triangle(700,220,750,250,700,280);
      pop();
    }

    if (keyCode===DOWN_ARROW && hardEnemyHealth>0){
      trianglePos=6;
      triangle(600,370,650,400,600,430);
      push();
      stroke(220);
      strokeWeight(10);
      triangle(700,220,750,250,700,280);  
      pop();
    }
    if (keyCode===UP_ARROW && easyEnemyHealth>0){
      trianglePos=5;
      triangle(700,220,750,250,700,280);
      push();
      stroke(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      pop();
    }
    else if (keyCode===85){  
    battleState=3; 
    }
    //backspace to go back to move select
    else if (keyCode===8){
      trianglePos=1;
      moveSelect=0;
      triangle(75,750,125,780,75,810);
      push();
      stroke(220);
      fill(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      triangle(700,220,750,250,700,280);
      pop();
      battleState=1;
    }
    
  }
  if (inBattle==1 && battleState==3){
     //calculate damage
    var damage;
    if (moveSelect==1){ 
    damageDealt = damageCalculate(power,3);
    }
    if (moveSelect==2){ 
    damageDealt = damageCalculate(power,1);
    }
    if (moveSelect==3){ 
    damageDealt = damageCalculate(power,6);
    }
    if (moveSelect==4){ 
    damageDealt = maxPlayerHealth*0.2;
    }
    push();
    noStroke();
    fill(220);
    rect(0,0,1000,600);
    pop();
    
    //restart mode/move to enemy turn
    playerTimer.start();
    eraseTriangle();
    battleState= 4;
    }
}

function keyReleased() {
  if (key == 'w') {
    movingUp = false;
  }
  if (key == 'a') {
    movingLeft = false;
  }
  if (key == 's') {
    movingDown = false;
  }
  if (key == 'd') {
    movingRight = false;
  }
}


/*function setup() {

	var strength = 132;

	// call function and pass the variable yourWeight into it

	var damageNumber = calculateDam(strength);

	// output variable marsWeight to console

	print(damageNumber);
}

// function calculateMars accepts a number and assigns the variable 'w' to it

function calculateDam(w) {

// the function uses this 'w' variable value in calculating a variable call newWeight

	var damage = w * 0.38;

// the variable newWeight value is returned  to line 9 where the function was called, there it is assigned to the variable marsWeight

	return damage;
}
*/