var inBattle = 1;
//state 1 is selecting move, state 2 is selecting enemy, state 3(?) is player damage phase
//state 0 is overworld movement, state 4 is enemy damage phase, state 5 is battle won, state 6 is level up(?)
var battleState = 1;
var trianglePos = 1;
var power = 10;
var secretKey = 0;
var ultraSecret = 0;
var playerHealth = 50;
var easyEnemyHealth = 30;
var hardEnemyHealth = 100;
var topEnemyX=850;
var topEnemyY=250;
var bottomEnemyX=750;
var bottomEnemyY=400;
var trianglePoints = [75,750,125,780,75,810];
var triangleTranslate1x=0;
var moveSelect = 0;
//need help figuring out the timer
//var enemyTimer=new Timer(5000);

function damageCalculate(x,y){
  var damage;
  if (moveSelect==1){
  damage = round(random(x*0.7,x*1.3));
  }
  if (moveSelect==2){
  damage = round(random(x,x*1.7));  
  }
  if (moveSelect==3){
  damage = x*0.8;  
  }
  var crit=random(1,10);
  if (crit<=y) {
    damage*=2;
  }
  return(damage);
}
//draw erase triangles according to movement
function eraseTriangle(){

  push();
  stroke(300);
  strokeWeight(10);
  triangle(75,750,125,780,75,810);
  triangle(525,750,575,780,525,810);
  triangle(525,850,575,880,525,910);
  triangle(75,850,125,880,75,910);
  pop();
}

//draws background, menu, and text as well as initial triangle
function setup() {
  createCanvas(1000, 1000);
  background(220);
  rect(50,700,900,250);
  textSize(50);
  text('Punch',150,800);
  text('Gun',600,800);
  text('Flamethrower',150,900);
  text('Heal',600,900);
  triangle(75,750,125,780,75,810);
}
//draws character,enemies, and health numbers, as well as descriptions(WIP) and battle end screen
function draw() {
  push();
  fill(0,250,150);
  ellipse(150,300,75,150);
  pop();
  rect(10,275,90,50);
  text(playerHealth,20,320);
  push();
  fill(250,200,0);
  ellipse(850,250,75,150);
  pop();
  rect(900,225,90,50);
  text(easyEnemyHealth,910,270);
  push();
  fill(255,0,0);
  ellipse(750,400,75,150);
  pop();
  rect(800,375,90,50);
  text(hardEnemyHealth,810,420);
  if (trianglePos==1){
    describe('Lunge forward and punch the enemy with all your might! Deals 70-130% Damage, 30% crit rate',LABEL);
  }
  if (trianglePos==2){
    describe('Fire your trusty gun at the enemy! Deals 100-170% damage, 10% crit rate',LABEL);
  }
  if (trianglePos==3){
    describe('Pull out your flamethrower and burn the enemy! Deals 80% damage, 60% crit rate',LABEL);
  }
  if (trianglePos==4){
    describe('Grab some bandages and restore your health! Recovers 20% of your max HP',LABEL);
  }
  if (trianglePos==5){
    describe('Easy Enemy',LABEL);
  }
    if (trianglePos==6){
    describe('Hard Enemy',LABEL);
  }
  
//  if (battleState==4&&enemyTimer.expired()){
//    alert("done");
//    battleState=1;
//  }
  
  if (easyEnemyHealth<=0){
    easyEnemyHealth=0;
    push();
    fill(220);
    stroke(220);
    strokeWeight(5);
    ellipse(850,250,75,150);
    rect(900,225,90,50);
    pop();
  }
  if (hardEnemyHealth<=0){
    hardEnemyHealth=0;
    push();
    fill(220);
    stroke(220);
    strokeWeight(5);
    ellipse(750,400,75,150);
    rect(800,375,90,50);
    pop();
  }
  if (easyEnemyHealth<=0&&hardEnemyHealth<=0){
    battleState=5;
    rect(0,0,1000);
    text('Battle Won!',400,500);
  }
}

//trianglePos/moveSelect 1/2/3/4 coresponds to A/B/C/D, tiranglePos 5/6 corresponds to top/bottom enemy

function keyPressed() {
  if (inBattle==1 && battleState==1){

    if (keyCode === LEFT_ARROW) {
      if (secretKey==2) {
      secretKey=3;
      print(secretKey);
      }
      if (trianglePos == 2) {
        //move to A
        eraseTriangle();
        triangle(75,750,125,780,75,810);
        trianglePos=1;
          }
      if (trianglePos == 4) {
        //move to C
        eraseTriangle();
        triangle(75,850,125,880,75,910);
        trianglePos=3;
      }
    } 
    else if (keyCode === RIGHT_ARROW) {
      if (secretKey==3) {
      secretKey=4;
      print(secretKey);
      }
        if (trianglePos == 1)
          {
            //move to B
            eraseTriangle();
            triangle(525,750,575,780,525,810);
            trianglePos=2;
          }
      if (trianglePos == 3)
          {
            //move to D
            eraseTriangle();
            triangle(525,850,575,880,525,910);
            trianglePos=4;
      }
    }
    else if (keyCode === UP_ARROW) {
      secretKey=1;
      print(secretKey);
      if (trianglePos == 3) {
        //move to A
        eraseTriangle();
        triangle(75,750,125,780,75,810);
        trianglePos=1;
          }
      if (trianglePos == 4) {
        //move to B
        eraseTriangle();
        triangle(525,750,575,780,525,810);
        trianglePos=2;
      }
    }
    else if (keyCode === DOWN_ARROW) {
      if (secretKey==1) {
      secretKey=2;
      print(secretKey);
      }
      if (trianglePos == 1) {
        //move to C
        eraseTriangle();
        triangle(75,850,125,880,75,910);
        trianglePos=3;
          }
      if (trianglePos == 2) {
        //move to D
        eraseTriangle();
        triangle(525,850,575,880,525,910);
        trianglePos=4;
      }
    }
    
    else if (keyCode === 32){
/*      if (secretKey==4){
      //cursor('progress');
      text('YOU JUST GOT COCONUT MALLED!',100,500);
      ultraSecret++;
      secretKey=0;
      } */
      if (ultraSecret>=5){
        text('HOLY SHIT AN ULTRA SECRET!!!',0,100);
      }
      if (trianglePos == 1||2||3||4){
        moveSelect=trianglePos;
        if(easyEnemyHealth==0){
        trianglePos=6;
        }
        else {
          trianglePos=5;
        }
        print(trianglePos);
        print(moveSelect);
        battleState=2;
      }
    }
        else {
    secretKey=0;
    }
  }
  if (inBattle==1 && battleState==2){
    //erase all triangles from move select
     push();
      stroke(300);
      strokeWeight(10);
      triangle(75,750,125,780,75,810);
      triangle(525,750,575,780,525,810);
      triangle(75,850,125,880,75,910);
      triangle(525,850,575,880,525,910);
      pop();
    //create triangles for enemies
    if (easyEnemyHealth>0){
      push();
    stroke(0);
    strokeWeight(1);
    fill(255);
    triangle(700,220,750,250,700,280);
      pop();
      push();
      stroke(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      pop();
    }
    else {
      push();
    stroke(0);
    strokeWeight(1);
    fill(255);
    triangle(600,370,650,400,600,430);  
      pop();
      push();
      stroke(220);
      strokeWeight(10);
      triangle(700,220,750,250,700,280);
      pop();
    }

    if (keyCode===DOWN_ARROW && hardEnemyHealth>0){
      trianglePos=6;
      print(trianglePos);
      triangle(600,370,650,400,600,430);
      push();
      stroke(220);
      strokeWeight(10);
      triangle(700,220,750,250,700,280);  
      pop();
    }
    if (keyCode===UP_ARROW && easyEnemyHealth>0){
      trianglePos=5;
      print(trianglePos);
      triangle(700,220,750,250,700,280);
      push();
      stroke(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      pop();
    }
    else if (keyCode===85){  
    battleState=3; 
    }
    //backspace to go back to move select
    else if (keyCode===8){
      trianglePos=1;
      moveSelect=0;
      triangle(75,750,125,780,75,810);
      push();
      stroke(220);
      fill(220);
      strokeWeight(10);
      triangle(600,370,650,400,600,430);
      triangle(700,220,750,250,700,280);
      pop();
      battleState=1;
    }
    
  }
  if (inBattle==1 && battleState==3){
     //calculate damage
    var damage;
    if (moveSelect==1){ 
    damage = damageCalculate(power,3);
    }
    if (moveSelect==2){ 
    damage = damageCalculate(power,1);
    }
    if (moveSelect==3){ 
    damage = damageCalculate(power,6);
    }
    if (moveSelect==4){ 
    damage = playerHealth*0.2;
    }
    print(damage);
    print(trianglePos);
    push();
    noStroke();
    fill(220);
    rect(0,0,1000,600);
    pop();
    if (trianglePos==5&&moveSelect!=4){
      text(damage,650,250);
      easyEnemyHealth-=damage;
    }
    if (trianglePos==6&&moveSelect!=4){
      hardEnemyHealth-=damage;
      text(damage,550,400);
    }
    if (moveSelect==4){
      text(damage,100,200)
      playerHealth+=damage;
    }
    if (easyEnemyHealth<0){
      easyEnemyHealth=0;
    }
    if (hardEnemyHealth<0){
      hardEnemyHealth=0;
    }
    if (playerHealth>50){
      playerHealth=50;
    }
    //restart mode/move to enemy turn
//    enemyTimer.start();
    trianglePos=1;
    moveState=0;
    triangle(75,750,125,780,75,810);
    print(easyEnemyHealth,hardEnemyHealth);
    battleState= /*4(this would be with the timer)*/  1;
    }
}


/*function setup() {

	var strength = 132;

	// call function and pass the variable yourWeight into it

	var damageNumber = calculateDam(strength);

	// output variable marsWeight to console

	print(damageNumber);
}

// function calculateMars accepts a number and assigns the variable 'w' to it

function calculateDam(w) {

// the function uses this 'w' variable value in calculating a variable call newWeight

	var damage = w * 0.38;

// the variable newWeight value is returned  to line 9 where the function was called, there it is assigned to the variable marsWeight

	return damage;
}
*/