var inBattle = 1;
var battleState = 1;
var trianglePos = 1;
var physStrength = 10;
var secretKey = 0;
var ultraSecret = 0;

function setup() {
  createCanvas(1000, 1000);
  background(220);
  rect(50,700,900,250);
  textSize(50);
  text('Punch',150,800);
  text('Option B',600,800);
  text('Option C',150,900);
  text('Option D',600,900);
  triangle(75,750,125,780,75,810);
}

//trianglePos 1/2/3/4 coresponds to A/B/C/D

function keyPressed() {
  if (inBattle==1 && battleState==1){
    if (keyCode === LEFT_ARROW) {
      if (secretKey==2) {
      secretKey=3;
      print(secretKey);
      }
      if (trianglePos == 2) {
        //move to A vanish B
        triangle(75,750,125,780,75,810);
        trianglePos=1;
        push();
        stroke(300);
        strokeWeight(10);
        triangle(525,750,575,780,525,810);
        pop();
        describe('Lunge forward and punch the enemy with all your might! Deals 70-130% Damage, 30% crit rate',LABEL)
          }
      if (trianglePos == 4) {
        //move to C vanish D
        triangle(75,850,125,880,75,910);
        trianglePos=3;
        push();
        stroke(300);
        strokeWeight(10);
        triangle(525,850,575,880,525,910);
        pop();
        describe('Cock',LABEL);
      }
    } 
    else if (keyCode === RIGHT_ARROW) {
      if (secretKey==3) {
      secretKey=4;
      print(secretKey);
      }
        if (trianglePos == 1)
          {
            //move to B vanish A
            triangle(525,750,575,780,525,810);
            trianglePos=2;
            push();
            stroke(300);
            strokeWeight(10);
            triangle(75,750,125,780,75,810);
            pop();
            describe('Bitch',LABEL);
          }
      if (trianglePos == 3)
          {
            //move to D vanish C
            triangle(525,850,575,880,525,910);
            trianglePos=4;
            push();
            stroke(300);
            strokeWeight(10);
            triangle(75,850,125,880,75,910);
            pop();
            describe('Deez nuts',LABEL);
      }
    }
    else if (keyCode === UP_ARROW) {
      secretKey=1;
      print(secretKey);
      if (trianglePos == 3) {
        //move to A vanish C
        triangle(75,750,125,780,75,810);
        trianglePos=1;
        push();
        stroke(300);
        strokeWeight(10);
        triangle(75,850,125,880,75,910);
        pop();
        describe('Lunge forward and punch the enemy with all your might! Deals 70-130% Damage, 30% crit rate',LABEL)
          }
      if (trianglePos == 4) {
        //move to B vanish D
        triangle(525,750,575,780,525,810);
        trianglePos=2;
        push();
        stroke(300);
        strokeWeight(10);
        triangle(525,850,575,880,525,910);
        pop();
        describe('Bitch',LABEL);
      }
    }
    else if (keyCode === DOWN_ARROW) {
      if (secretKey==1) {
      secretKey=2;
      print(secretKey);
      }
      if (trianglePos == 1) {
        //move to C vanish A
        triangle(75,850,125,880,75,910);
        trianglePos=3;
        push();
        stroke(300);
        strokeWeight(10);
        triangle(75,750,125,780,75,810);
        pop();
        describe('Cock',LABEL);
          }
      if (trianglePos == 2) {
        //move to D vanish B
        triangle(525,850,575,880,525,910);
        trianglePos=4;
        push();
        stroke(300);
        strokeWeight(10);
        triangle(525,750,575,780,525,810);
        pop();
        describe('Deez nuts',LABEL);
      }
    }
    
    else if (keyCode === 32){
      if (secretKey==4){
      cursor('progress');
      text('YOU JUST GOT COCONUT MALLED!',100,500);
      ultraSecret++;
      secretKey=0;
      }
      if (ultraSecret>=5){
        text('HOLY SHIT AN ULTRA SECRET!!!',0,100);
      }
      if (trianglePos == 1){
        //background(200,0,0);
        var damageNumber = round(random(physStrength*0.7,physStrength*1.3));
        var crit=random(1,10);
        if (crit<=3) {
          damageNumber*=2;
        }
        print(damageNumber);
        push();
        noStroke();
        fill(220);
        rect(0,0,1000,600);
        pop();
        text(damageNumber,300,300);
      }
      if (trianglePos == 2){
        //background(150,100,0);
      }
      if (trianglePos == 3){
        //background(0,200,0);
      }
      if (trianglePos == 4){
        //background(0,0,200);
      }
    }
  }
    else {
    secretKey=0;
  }
}


/*function keyPressed() {
  if (keyCode===UP_ARROW){
    secretKey=1;
    print(secretKey);
  }
  else if (keyCode===DOWN_ARROW&&secretKey==1){
    secretKey=2;
    print(secretKey);
  }
  else if (keyCode===LEFT_ARROW&&secretKey==2){
    secretKey=3;
    print(secretKey);
  }
  else if (keyCode===RIGHT_ARROW&&secretKey==3){
    secretKey=4;
    print(secretKey);
  }
  else if (secretKey==4 && keyCode===32){
    cursor('progress');
    text('YOU JUST GOT COCONUT MALLED!',100,500);
  }
  else {
    secretKey=0;
  }
  
}
*/